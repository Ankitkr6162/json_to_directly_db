package io.spring.json.parse.db.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import io.spring.json.parse.db.entities.User;

public interface UserRepository extends JpaRepository<User, Integer> {

}
