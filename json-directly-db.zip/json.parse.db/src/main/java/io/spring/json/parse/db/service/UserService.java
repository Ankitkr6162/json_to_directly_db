package io.spring.json.parse.db.service;

import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import io.spring.json.parse.db.entities.User;
import io.spring.json.parse.db.repositories.UserRepository;
import io.spring.json.parse.db.dto.UserDTO;

@Service
public class UserService {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private UserRepository userRepository;
	
	public void fetchDataAndSaveToDatabase() {
		
		String apiUrl = "https://jsonplaceholder.typicode.com/comments";
		
		ResponseEntity<UserDTO[]> responseEntity = restTemplate.getForEntity(apiUrl, UserDTO[].class);
		UserDTO[] userDtos = responseEntity.getBody();
		
		if (userDtos != null) {
			for(UserDTO userDto : userDtos) {
				User user = new User();
				user.setPostId(userDto.getPostId());
				user.setId(userDto.getId());
				user.setName(userDto.getName());
				user.setEmail(userDto.getEmail());
				user.setBody(userDto.getBody());
				
				userRepository.save(user);
			}
		}
		
		
		}
		
	}

